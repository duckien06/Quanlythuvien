"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Plus, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BorrowTable } from "@/components/borrow-table"
import { CustomerTable } from "@/components/customer-table"
import { ReturnedBooksTable } from "@/components/returned-books-table"
import { ReturnedCustomerTable } from "@/components/returned-customer-table"
import { AddBookLoanDialog } from "@/components/add-book-loan-dialog"
import { SuccessDialog } from "@/components/success-dialog"
import { CustomerDetailDialog } from "@/components/customer-detail-dialog"
import { ReturnedCustomerDetailDialog } from "@/components/returned-customer-detail-dialog"
import { EditBookLoanDialog } from "@/components/edit-book-loan-dialog"
import { ReturnBookDialog } from "@/components/return-book-dialog"
import { LostBookDialog } from "@/components/lost-book-dialog"
import { DeleteConfirmDialog } from "@/components/delete-confirm-dialog"
import { useLibraryStore } from "@/lib/store"

export default function BorrowReturnPage() {
  const [activeTab, setActiveTab] = useState("borrow")
  const [borrowViewMode, setBorrowViewMode] = useState<"book" | "customer">("book")
  const [returnViewMode, setReturnViewMode] = useState<"book" | "customer">("book")
  const [borrowSearchTerm, setBorrowSearchTerm] = useState("")
  const [returnSearchTerm, setReturnSearchTerm] = useState("")

  // Dialog states
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isSuccessDialogOpen, setIsSuccessDialogOpen] = useState(false)
  const [successMessage, setSuccessMessage] = useState("Added successfully")
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null)
  const [selectedReturnedCustomer, setSelectedReturnedCustomer] = useState<string | null>(null)
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isReturnDialogOpen, setIsReturnDialogOpen] = useState(false)
  const [isLostDialogOpen, setIsLostDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  // Get data from store
  const {
    borrowedBooks,
    returnedBooks,
    customers,
    addBorrowedBook,
    updateBorrowedBook,
    deleteBorrowedBook,
    returnBook,
    markBookAsLost,
  } = useLibraryStore()

  // Filter data based on search term
  const filteredBorrowedBooks = borrowedBooks.filter(
    (item) =>
      item.status === "borrowed" &&
      (item.customerName.toLowerCase().includes(borrowSearchTerm.toLowerCase()) ||
        item.bookTitle.toLowerCase().includes(borrowSearchTerm.toLowerCase())),
  )

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(borrowSearchTerm.toLowerCase()) || customer.phone.includes(borrowSearchTerm),
  )

  const filteredReturnedBooks = returnedBooks.filter(
    (item) =>
      item.status === "returned" &&
      (item.customerName.toLowerCase().includes(returnSearchTerm.toLowerCase()) ||
        item.bookTitle.toLowerCase().includes(returnSearchTerm.toLowerCase())),
  )

  // Get unique customers who have returned books
  const returnedCustomers = Array.from(
    new Set(returnedBooks.filter((book) => book.status === "returned").map((book) => book.customerId)),
  )
    .map((customerId) => {
      const customer = customers.find((c) => c.id === customerId)
      const customerReturnedBooks = returnedBooks.filter(
        (book) => book.customerId === customerId && book.status === "returned",
      )

      return {
        id: customerId,
        name: customer?.name || customerReturnedBooks[0]?.customerName || "",
        phone: customer?.phone || customerReturnedBooks[0]?.customerPhone || "",
        returnedQuantity: customerReturnedBooks.length,
      }
    })
    .filter(
      (customer) =>
        customer.name.toLowerCase().includes(returnSearchTerm.toLowerCase()) ||
        customer.phone.includes(returnSearchTerm),
    )

  const handleAddSuccess = (data: any) => {
    addBorrowedBook(data)
    setIsAddDialogOpen(false)
    setSuccessMessage("Added successfully")
    setIsSuccessDialogOpen(true)
  }

  const handleEditSuccess = (id: string, data: any) => {
    updateBorrowedBook(id, data)
    setIsEditDialogOpen(false)
    setSuccessMessage("Updated successfully")
    setIsSuccessDialogOpen(true)
  }

  const handleReturnBook = (id: string) => {
    returnBook(id)
    setIsReturnDialogOpen(false)
    setSuccessMessage("Returned book successfully")
    setIsSuccessDialogOpen(true)
  }

  const handleLostBook = (id: string, price: number, discount: number) => {
    markBookAsLost(id, price, discount)
    setIsLostDialogOpen(false)
    setSuccessMessage("Lost book processed successfully")
    setIsSuccessDialogOpen(true)
  }

  const handleDeleteBook = (id: string) => {
    deleteBorrowedBook(id)
    setIsDeleteDialogOpen(false)
    setSuccessMessage("Deleted successfully")
    setIsSuccessDialogOpen(true)
  }

  const handleViewCustomerDetails = (customerId: string) => {
    setSelectedCustomer(customerId)
  }

  const handleViewReturnedCustomerDetails = (customerId: string) => {
    setSelectedReturnedCustomer(customerId)
  }

  const handleEditBook = (bookId: string) => {
    setSelectedBookId(bookId)
    setIsEditDialogOpen(true)
  }

  const handleReturnBookClick = (bookId: string) => {
    setSelectedBookId(bookId)
    setIsReturnDialogOpen(true)
  }

  const handleLostBookClick = (bookId: string) => {
    setSelectedBookId(bookId)
    setIsLostDialogOpen(true)
  }

  const handleDeleteBookClick = (bookId: string) => {
    setSelectedBookId(bookId)
    setIsDeleteDialogOpen(true)
  }

  return (
    <div className="flex-1 p-6">
      <div className="mb-6">
        <Link href="/">
          <Button variant="ghost" className="flex items-center gap-1 text-gray-600 hover:text-gray-900 pl-0">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
        </Link>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 w-full max-w-md mx-auto mb-6">
          <TabsTrigger value="borrow">Borrow books</TabsTrigger>
          <TabsTrigger value="return">Return books</TabsTrigger>
        </TabsList>

        <TabsContent value="borrow" className="mt-0">
          <div className="flex justify-between items-center mb-6">
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              ADD
            </Button>
          </div>

          <div className="flex gap-2 mb-6">
            <Button
              variant={borrowViewMode === "book" ? "default" : "outline"}
              className={`rounded-full px-6 ${borrowViewMode === "book" ? "bg-green-500 hover:bg-green-600" : "bg-gray-200 hover:bg-gray-300 text-gray-700"}`}
              onClick={() => setBorrowViewMode("book")}
            >
              Book
            </Button>
            <Button
              variant={borrowViewMode === "customer" ? "default" : "outline"}
              className={`rounded-full px-6 ${borrowViewMode === "customer" ? "bg-green-500 hover:bg-green-600" : "bg-gray-200 hover:bg-gray-300 text-gray-700"}`}
              onClick={() => setBorrowViewMode("customer")}
            >
              Customer
            </Button>
          </div>

          <div className="relative w-full max-w-sm mb-6">
            <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="search"
              placeholder="Search..."
              className="pl-8 bg-gray-100 border-none"
              value={borrowSearchTerm}
              onChange={(e) => setBorrowSearchTerm(e.target.value)}
            />
          </div>

          {borrowViewMode === "book" ? (
            <BorrowTable
              borrowedBooks={filteredBorrowedBooks}
              onEdit={handleEditBook}
              onDelete={handleDeleteBookClick}
            />
          ) : (
            <CustomerTable customers={filteredCustomers} onViewDetails={handleViewCustomerDetails} />
          )}
        </TabsContent>

        <TabsContent value="return" className="mt-0">
          <div className="flex gap-2 mb-6">
            <Button
              variant={returnViewMode === "book" ? "default" : "outline"}
              className={`rounded-full px-6 ${returnViewMode === "book" ? "bg-green-500 hover:bg-green-600" : "bg-gray-200 hover:bg-gray-300 text-gray-700"}`}
              onClick={() => setReturnViewMode("book")}
            >
              Book
            </Button>
            <Button
              variant={returnViewMode === "customer" ? "default" : "outline"}
              className={`rounded-full px-6 ${returnViewMode === "customer" ? "bg-green-500 hover:bg-green-600" : "bg-gray-200 hover:bg-gray-300 text-gray-700"}`}
              onClick={() => setReturnViewMode("customer")}
            >
              Customer
            </Button>
          </div>

          <div className="relative w-full max-w-sm mb-6">
            <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="search"
              placeholder="Search..."
              className="pl-8 bg-gray-100 border-none"
              value={returnSearchTerm}
              onChange={(e) => setReturnSearchTerm(e.target.value)}
            />
          </div>

          {returnViewMode === "book" ? (
            <ReturnedBooksTable returnedBooks={filteredReturnedBooks} />
          ) : (
            <ReturnedCustomerTable customers={returnedCustomers} onViewDetails={handleViewReturnedCustomerDetails} />
          )}
        </TabsContent>
      </Tabs>

      {/* Add Book Loan Dialog */}
      <AddBookLoanDialog
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onSuccess={handleAddSuccess}
        customers={customers}
      />

      {/* Edit Book Loan Dialog */}
      <EditBookLoanDialog
        isOpen={isEditDialogOpen}
        bookId={selectedBookId}
        borrowedBooks={borrowedBooks}
        onClose={() => setIsEditDialogOpen(false)}
        onSuccess={handleEditSuccess}
        onReturnBook={handleReturnBookClick}
        onLostBook={handleLostBookClick}
      />

      {/* Return Book Dialog */}
      <ReturnBookDialog
        isOpen={isReturnDialogOpen}
        bookId={selectedBookId}
        borrowedBooks={borrowedBooks}
        onClose={() => setIsReturnDialogOpen(false)}
        onSuccess={handleReturnBook}
      />

      {/* Lost Book Dialog */}
      <LostBookDialog
        isOpen={isLostDialogOpen}
        bookId={selectedBookId}
        borrowedBooks={borrowedBooks}
        onClose={() => setIsLostDialogOpen(false)}
        onSuccess={handleLostBook}
      />

      {/* Delete Confirm Dialog */}
      <DeleteConfirmDialog
        isOpen={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={() => selectedBookId && handleDeleteBook(selectedBookId)}
      />

      {/* Success Dialog */}
      <SuccessDialog
        isOpen={isSuccessDialogOpen}
        onClose={() => setIsSuccessDialogOpen(false)}
        message={successMessage}
      />

      {/* Customer Detail Dialog */}
      <CustomerDetailDialog
        customerId={selectedCustomer}
        onClose={() => setSelectedCustomer(null)}
        onEdit={handleEditBook}
        onDelete={handleDeleteBookClick}
      />

      {/* Returned Customer Detail Dialog */}
      <ReturnedCustomerDetailDialog
        customerId={selectedReturnedCustomer}
        onClose={() => setSelectedReturnedCustomer(null)}
      />
    </div>
  )
}

