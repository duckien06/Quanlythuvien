import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import dynamic from "next/dynamic"
import Sidebar from "@/components/sidebar"

const DynamicHeader = dynamic(() => import("@/components/header"), {
  ssr: false,
  loading: () => <div className="h-[3rem] bg-white border-b border-gray-200"></div>,
})

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "eLibrary - Library Management System",
  description: "A comprehensive library management system",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen bg-gray-50 flex flex-col">
          <DynamicHeader />
          <div className="flex flex-1">
            <Sidebar />
            <main className="flex-1">{children}</main>
          </div>
        </div>
      </body>
    </html>
  )
}



import './globals.css'