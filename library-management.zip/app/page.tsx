"use client"

import { useSearchParams } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { BookTable } from "@/components/book-table"
import { books } from "@/lib/data"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Home() {
  const searchParams = useSearchParams()
  const searchQuery = searchParams.get("q")

  // Filter books based on search query if it exists
  const searchResults = searchQuery
    ? books.filter(
        (book) =>
          book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          book.author.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : null

  return (
    <div className="flex-1 p-6">
      {!searchQuery ? (
        <h1 className="text-2xl font-semibold text-gray-800">Home</h1>
      ) : (
        <>
          <div className="mb-6">
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-1 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
            </Link>
            <h1 className="text-2xl font-semibold text-gray-800 mt-2">Search results</h1>
          </div>

          {searchResults && searchResults.length > 0 ? (
            <BookTable books={searchResults} />
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No books found matching "{searchQuery}"</p>
              <Link href="/">
                <Button variant="link" className="mt-2">
                  Clear search
                </Button>
              </Link>
            </div>
          )}
        </>
      )}
    </div>
  )
}

