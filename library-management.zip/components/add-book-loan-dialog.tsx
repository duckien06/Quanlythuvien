"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import type { Customer } from "@/lib/types"

interface AddBookLoanDialogProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: (data: any) => void
  customers: Customer[]
}

interface FormData {
  customerId: string
  customerName: string
  customerPhone: string
  bookId: string
  bookTitle: string
  bookCategory: string
  borrowedDate: string
  returnDate: string
}

interface FormErrors {
  customerName?: string
  customerPhone?: string
  bookTitle?: string
  bookCategory?: string
  borrowedDate?: string
  returnDate?: string
  dateComparison?: string
}

export function AddBookLoanDialog({ isOpen, onClose, onSuccess, customers }: AddBookLoanDialogProps) {
  const [formData, setFormData] = useState<FormData>({
    customerId: "",
    customerName: "",
    customerPhone: "",
    bookId: `book-${Date.now()}`,
    bookTitle: "",
    bookCategory: "",
    borrowedDate: "",
    returnDate: "",
  })

  const [borrowedDateInput, setBorrowedDateInput] = useState("")
  const [returnDateInput, setReturnDateInput] = useState("")
  const [errors, setErrors] = useState<FormErrors>({})

  // Validate dates whenever either date changes
  useEffect(() => {
    if (formData.borrowedDate && formData.returnDate) {
      validateDates(formData.borrowedDate, formData.returnDate)
    }
  }, [formData.borrowedDate, formData.returnDate])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // If changing name, try to find customer and auto-fill phone
    if (name === "customerName") {
      const customer = customers.find((c) => c.name.toLowerCase() === value.toLowerCase())
      if (customer) {
        setFormData((prev) => ({
          ...prev,
          customerId: customer.id,
          customerPhone: customer.phone,
        }))
      }
    }

    // If changing phone, validate it contains only numbers
    if (name === "customerPhone") {
      // Check if input contains only numbers
      if (!/^\d*$/.test(value)) {
        setErrors((prev) => ({
          ...prev,
          customerPhone: "Phone number must contain only digits",
        }))
        return // Don't update the form data with invalid input
      }
    }

    // Clear error when user types
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }))
    }
  }

  const validateDates = (borrowedDate: string, returnDate: string): boolean => {
    // Convert DD.MM.YYYY to Date objects for comparison
    const [borrowedDay, borrowedMonth, borrowedYear] = borrowedDate.split(".").map(Number)
    const [returnDay, returnMonth, returnYear] = returnDate.split(".").map(Number)

    const borrowedDateObj = new Date(borrowedYear, borrowedMonth - 1, borrowedDay)
    const returnDateObj = new Date(returnYear, returnMonth - 1, returnDay)

    if (borrowedDateObj >= returnDateObj) {
      setErrors((prev) => ({
        ...prev,
        dateComparison: "Borrowed date must be earlier than return date",
      }))
      return false
    } else {
      setErrors((prev) => ({
        ...prev,
        dateComparison: undefined,
      }))
      return true
    }
  }

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {}
    let isValid = true

    // Validate each field
    if (!formData.customerName.trim()) {
      newErrors.customerName = "Name is required"
      isValid = false
    }

    if (!formData.customerPhone.trim()) {
      newErrors.customerPhone = "Phone is required"
      isValid = false
    }

    if (!/^\d+$/.test(formData.customerPhone.trim())) {
      newErrors.customerPhone = "Phone number must contain only digits"
      isValid = false
    }

    if (!formData.bookTitle.trim()) {
      newErrors.bookTitle = "Book is required"
      isValid = false
    }

    if (!formData.bookCategory.trim()) {
      newErrors.bookCategory = "Category is required"
      isValid = false
    }

    if (!formData.borrowedDate.trim()) {
      newErrors.borrowedDate = "Borrowed date is required"
      isValid = false
    }

    if (!formData.returnDate.trim()) {
      newErrors.returnDate = "Return date is required"
      isValid = false
    }

    // Validate date comparison if both dates are provided
    if (formData.borrowedDate && formData.returnDate) {
      const datesValid = validateDates(formData.borrowedDate, formData.returnDate)
      if (!datesValid) {
        isValid = false
      }
    }

    setErrors((prev) => ({ ...prev, ...newErrors }))
    return isValid
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (validateForm()) {
      // If customer doesn't exist, create a new ID
      if (!formData.customerId) {
        formData.customerId = `c${customers.length + 1}`
      }

      onSuccess(formData)

      // Reset form
      setFormData({
        customerId: "",
        customerName: "",
        customerPhone: "",
        bookId: `book-${Date.now()}`,
        bookTitle: "",
        bookCategory: "",
        borrowedDate: "",
        returnDate: "",
      })
      setBorrowedDateInput("")
      setReturnDateInput("")
      setErrors({})
    }
  }

  const formatDateForInput = (date: string) => {
    if (!date) return ""
    const [day, month, year] = date.split(".")
    return `${year}-${month}-${day}`
  }

  const formatDateForDisplay = (date: string) => {
    if (!date) return ""
    const [year, month, day] = date.split("-")
    return `${day}.${month}.${year}`
  }

  const handleBorrowedDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputDate = e.target.value // YYYY-MM-DD
    setBorrowedDateInput(inputDate)

    if (inputDate) {
      const formattedDate = formatDateForDisplay(inputDate)
      setFormData((prev) => ({
        ...prev,
        borrowedDate: formattedDate,
      }))

      if (errors.borrowedDate) {
        setErrors((prev) => ({ ...prev, borrowedDate: undefined }))
      }
    }
  }

  const handleReturnDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputDate = e.target.value // YYYY-MM-DD
    setReturnDateInput(inputDate)

    if (inputDate) {
      const formattedDate = formatDateForDisplay(inputDate)
      setFormData((prev) => ({
        ...prev,
        returnDate: formattedDate,
      }))

      if (errors.returnDate) {
        setErrors((prev) => ({ ...prev, returnDate: undefined }))
      }
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-lg font-bold">ADD BOOK LOAN</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customerName" className="uppercase text-xs font-semibold">
                Name
              </Label>
              <Input
                id="customerName"
                name="customerName"
                value={formData.customerName}
                onChange={handleChange}
                className={errors.customerName ? "border-red-500" : ""}
              />
              {errors.customerName && <p className="text-red-500 text-xs">{errors.customerName}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerPhone" className="uppercase text-xs font-semibold">
                Phone
              </Label>
              <Input
                id="customerPhone"
                name="customerPhone"
                value={formData.customerPhone}
                onChange={handleChange}
                className={errors.customerPhone ? "border-red-500" : ""}
              />
              {errors.customerPhone && <p className="text-red-500 text-xs">{errors.customerPhone}</p>}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bookTitle" className="uppercase text-xs font-semibold">
              Book
            </Label>
            <Input
              id="bookTitle"
              name="bookTitle"
              value={formData.bookTitle}
              onChange={handleChange}
              className={errors.bookTitle ? "border-red-500" : ""}
            />
            {errors.bookTitle && <p className="text-red-500 text-xs">{errors.bookTitle}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="bookCategory" className="uppercase text-xs font-semibold">
              Category
            </Label>
            <Input
              id="bookCategory"
              name="bookCategory"
              value={formData.bookCategory}
              onChange={handleChange}
              className={errors.bookCategory ? "border-red-500" : ""}
            />
            {errors.bookCategory && <p className="text-red-500 text-xs">{errors.bookCategory}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="borrowedDate" className="uppercase text-xs font-semibold">
              Borrowed date
            </Label>
            <Input
              id="borrowedDate"
              name="borrowedDate"
              type="date"
              value={borrowedDateInput}
              onChange={handleBorrowedDateChange}
              className={errors.borrowedDate || errors.dateComparison ? "border-red-500" : ""}
            />
            {formData.borrowedDate && <p className="text-xs text-gray-500">Selected: {formData.borrowedDate}</p>}
            {errors.borrowedDate && <p className="text-red-500 text-xs">{errors.borrowedDate}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="returnDate" className="uppercase text-xs font-semibold">
              Return date
            </Label>
            <Input
              id="returnDate"
              name="returnDate"
              type="date"
              value={returnDateInput}
              onChange={handleReturnDateChange}
              className={errors.returnDate || errors.dateComparison ? "border-red-500" : ""}
            />
            {formData.returnDate && <p className="text-xs text-gray-500">Selected: {formData.returnDate}</p>}
            {errors.returnDate && <p className="text-red-500 text-xs">{errors.returnDate}</p>}
          </div>

          {errors.dateComparison && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-2 rounded-md text-sm">
              {errors.dateComparison}
            </div>
          )}

          <div className="flex justify-center gap-4 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              OK
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

