"use client"

import { Pencil, Trash2 } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import type { BorrowedBook } from "@/lib/types"

interface BorrowTableProps {
  borrowedBooks: BorrowedBook[]
  onEdit: (id: string) => void
  onDelete: (id: string) => void
}

export function BorrowTable({ borrowedBooks, onEdit, onDelete }: BorrowTableProps) {
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Phone</TableHead>
            <TableHead>Book</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Borrowed date</TableHead>
            <TableHead>Return date</TableHead>
            <TableHead className="w-[100px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {borrowedBooks.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.customerName}</TableCell>
              <TableCell>{item.customerPhone}</TableCell>
              <TableCell>{item.bookTitle}</TableCell>
              <TableCell>{item.bookCategory}</TableCell>
              <TableCell>{item.borrowedDate}</TableCell>
              <TableCell>{item.returnDate}</TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(item.id)}>
                    <Pencil className="h-4 w-4 text-blue-500" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onDelete(item.id)}>
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
          {borrowedBooks.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                No borrowed books found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  )
}

