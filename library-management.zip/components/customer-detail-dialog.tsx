"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Pencil, Trash2 } from "lucide-react"
import { useLibraryStore } from "@/lib/store"

interface CustomerDetailDialogProps {
  customerId: string | null
  onClose: () => void
  onEdit: (bookId: string) => void
  onDelete: (bookId: string) => void
}

export function CustomerDetailDialog({ customerId, onClose, onEdit, onDelete }: CustomerDetailDialogProps) {
  const { borrowedBooks } = useLibraryStore()

  if (!customerId) return null

  // Get customer's borrowed books
  const customerBooks = borrowedBooks.filter((book) => book.customerId === customerId && book.status === "borrowed")

  // Get customer name from the first book (if any)
  const customerName = customerBooks.length > 0 ? customerBooks[0].customerName : "Customer"

  return (
    <Dialog open={!!customerId} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px]">
        <DialogHeader>
          <DialogTitle>Books borrowed by {customerName}</DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Book</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Borrowed date</TableHead>
                <TableHead>Return date</TableHead>
                <TableHead className="w-[100px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customerBooks.map((book) => (
                <TableRow key={book.id}>
                  <TableCell>{book.bookTitle}</TableCell>
                  <TableCell>{book.bookCategory}</TableCell>
                  <TableCell>{book.borrowedDate}</TableCell>
                  <TableCell>{book.returnDate}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => {
                          onClose()
                          onEdit(book.id)
                        }}
                      >
                        <Pencil className="h-4 w-4 text-blue-500" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => {
                          onClose()
                          onDelete(book.id)
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {customerBooks.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                    No borrowed books found for this customer
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  )
}

