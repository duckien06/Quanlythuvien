"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import type { BorrowedBook } from "@/lib/types"

interface EditBookLoanDialogProps {
  isOpen: boolean
  bookId: string | null
  borrowedBooks: BorrowedBook[]
  onClose: () => void
  onSuccess: (id: string, data: any) => void
  onReturnBook: (id: string) => void
  onLostBook: (id: string) => void
}

interface FormData {
  customerName: string
  customerPhone: string
  bookTitle: string
  bookCategory: string
  borrowedDate: string
  returnDate: string
}

interface FormErrors {
  customerName?: string
  customerPhone?: string
  bookTitle?: string
  bookCategory?: string
  borrowedDate?: string
  returnDate?: string
}

export function EditBookLoanDialog({
  isOpen,
  bookId,
  borrowedBooks,
  onClose,
  onSuccess,
  onReturnBook,
  onLostBook,
}: EditBookLoanDialogProps) {
  const [formData, setFormData] = useState<FormData>({
    customerName: "",
    customerPhone: "",
    bookTitle: "",
    bookCategory: "",
    borrowedDate: "",
    returnDate: "",
  })

  const [errors, setErrors] = useState<FormErrors>({})

  // Load book data when dialog opens
  useEffect(() => {
    if (isOpen && bookId) {
      const book = borrowedBooks.find((b) => b.id === bookId)
      if (book) {
        setFormData({
          customerName: book.customerName,
          customerPhone: book.customerPhone,
          bookTitle: book.bookTitle,
          bookCategory: book.bookCategory,
          borrowedDate: book.borrowedDate,
          returnDate: book.returnDate,
        })
      }
    }
  }, [isOpen, bookId, borrowedBooks])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear error when user types
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }))
    }
  }

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {}
    let isValid = true

    // Validate each field
    if (!formData.customerName.trim()) {
      newErrors.customerName = "Name is required"
      isValid = false
    }

    if (!formData.customerPhone.trim()) {
      newErrors.customerPhone = "Phone is required"
      isValid = false
    }

    if (!formData.bookTitle.trim()) {
      newErrors.bookTitle = "Book is required"
      isValid = false
    }

    if (!formData.bookCategory.trim()) {
      newErrors.bookCategory = "Category is required"
      isValid = false
    }

    if (!formData.borrowedDate.trim()) {
      newErrors.borrowedDate = "Borrowed date is required"
      isValid = false
    }

    if (!formData.returnDate.trim()) {
      newErrors.returnDate = "Return date is required"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (validateForm() && bookId) {
      onSuccess(bookId, formData)
    }
  }

  const handleReturnBook = () => {
    if (bookId) {
      onClose()
      onReturnBook(bookId)
    }
  }

  const handleLostBook = () => {
    if (bookId) {
      onClose()
      onLostBook(bookId)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] p-0 overflow-hidden">
        <DialogHeader className="p-6 pb-2">
          <DialogTitle className="text-xl font-bold">Information</DialogTitle>
        </DialogHeader>

        <div className="flex">
          <div className="flex-1 bg-gray-200 p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="customerName" className="uppercase text-xs font-semibold">
                  NAME
                </Label>
                <Input
                  id="customerName"
                  name="customerName"
                  value={formData.customerName}
                  onChange={handleChange}
                  className={`bg-white ${errors.customerName ? "border-red-500" : ""}`}
                />
                {errors.customerName && <p className="text-red-500 text-xs">{errors.customerName}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="customerPhone" className="uppercase text-xs font-semibold">
                  PHONE
                </Label>
                <Input
                  id="customerPhone"
                  name="customerPhone"
                  value={formData.customerPhone}
                  onChange={handleChange}
                  className={`bg-white ${errors.customerPhone ? "border-red-500" : ""}`}
                />
                {errors.customerPhone && <p className="text-red-500 text-xs">{errors.customerPhone}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="bookTitle" className="uppercase text-xs font-semibold">
                  BOOK
                </Label>
                <Input
                  id="bookTitle"
                  name="bookTitle"
                  value={formData.bookTitle}
                  onChange={handleChange}
                  className={`bg-white ${errors.bookTitle ? "border-red-500" : ""}`}
                />
                {errors.bookTitle && <p className="text-red-500 text-xs">{errors.bookTitle}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="bookCategory" className="uppercase text-xs font-semibold">
                  CATEGORY
                </Label>
                <Input
                  id="bookCategory"
                  name="bookCategory"
                  value={formData.bookCategory}
                  onChange={handleChange}
                  className={`bg-white ${errors.bookCategory ? "border-red-500" : ""}`}
                />
                {errors.bookCategory && <p className="text-red-500 text-xs">{errors.bookCategory}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="borrowedDate" className="uppercase text-xs font-semibold">
                  Borrowed date
                </Label>
                <Input
                  id="borrowedDate"
                  name="borrowedDate"
                  value={formData.borrowedDate}
                  onChange={handleChange}
                  className={`bg-white ${errors.borrowedDate ? "border-red-500" : ""}`}
                />
                {errors.borrowedDate && <p className="text-red-500 text-xs">{errors.borrowedDate}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="returnDate" className="uppercase text-xs font-semibold">
                  Return date
                </Label>
                <Input
                  id="returnDate"
                  name="returnDate"
                  value={formData.returnDate}
                  onChange={handleChange}
                  className={`bg-white ${errors.returnDate ? "border-red-500" : ""}`}
                />
                {errors.returnDate && <p className="text-red-500 text-xs">{errors.returnDate}</p>}
              </div>
            </form>
          </div>

          <div className="w-64 p-6 flex flex-col gap-4">
            <Button type="button" className="bg-blue-600 hover:bg-blue-700 w-full py-6" onClick={handleReturnBook}>
              RETURN BOOK
            </Button>
            <Button type="button" className="bg-red-500 hover:bg-red-600 w-full py-6" onClick={handleLostBook}>
              LOST BOOK
            </Button>
          </div>
        </div>

        <div className="flex justify-end gap-4 p-4 border-t">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" className="bg-blue-600 hover:bg-blue-700" onClick={handleSubmit}>
            Save
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

