"use client"

import { useRouter, usePathname } from "next/navigation"
import { Suspense } from "react"
import Image from "next/image"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ChevronDown } from "lucide-react"
import { SearchForm } from "@/components/search-form"

export default function Header() {
  const router = useRouter()
  const pathname = usePathname()

  // Check if current page is Borrow/Return Books page
  const isBorrowReturnPage = pathname === "/borrow-return"

  return (
    <header className="bg-white border-b border-gray-200 py-2 px-4 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="relative h-8 w-8">
          <Image src="/logo.png" alt="eLibrary Logo" width={32} height={32} className="object-contain" />
        </div>
        <h1 className="text-xl font-bold text-blue-600">eLibrary</h1>
      </div>

      {!isBorrowReturnPage && (
        <div className="flex-1 max-w-md mx-4">
          <Suspense fallback={<div className="h-9 bg-gray-100 rounded-md animate-pulse"></div>}>
            <SearchForm />
          </Suspense>
        </div>
      )}

      <DropdownMenu>
        <DropdownMenuTrigger className="flex items-center gap-2 outline-none">
          <Avatar className="h-8 w-8">
            <AvatarImage src="/placeholder.svg?height=32&width=32" />
            <AvatarFallback>AD</AvatarFallback>
          </Avatar>
          <span className="text-sm text-gray-700">Manage</span>
          <ChevronDown className="h-4 w-4 text-gray-500" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>My Account</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>Profile</DropdownMenuItem>
          <DropdownMenuItem>Settings</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem>Log out</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}

