"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import type { BorrowedBook } from "@/lib/types"

interface LostBookDialogProps {
  isOpen: boolean
  bookId: string | null
  borrowedBooks: BorrowedBook[]
  onClose: () => void
  onSuccess: (id: string, price: number, discount: number) => void
}

interface FormData {
  bookTitle: string
  price: number
  discount: number
  totalPayment: number
}

export function LostBookDialog({ isOpen, bookId, borrowedBooks, onClose, onSuccess }: LostBookDialogProps) {
  const [formData, setFormData] = useState<FormData>({
    bookTitle: "",
    price: 0,
    discount: 0,
    totalPayment: 0,
  })

  // Load book data when dialog opens
  useEffect(() => {
    if (isOpen && bookId) {
      const book = borrowedBooks.find((b) => b.id === bookId)
      if (book) {
        setFormData({
          bookTitle: book.bookTitle,
          price: 70000, // Default price
          discount: 0,
          totalPayment: 70000,
        })
      }
    }
  }, [isOpen, bookId, borrowedBooks])

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const price = Number.parseFloat(e.target.value) || 0
    setFormData((prev) => ({
      ...prev,
      price,
      totalPayment: price - prev.discount,
    }))
  }

  const handleDiscountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const discount = Number.parseFloat(e.target.value) || 0
    setFormData((prev) => ({
      ...prev,
      discount,
      totalPayment: prev.price - discount,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (bookId) {
      onSuccess(bookId, formData.price, formData.discount)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-lg font-bold">LOST BOOK</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="bookTitle" className="uppercase text-xs font-semibold">
              Book Title
            </Label>
            <Input id="bookTitle" value={formData.bookTitle} readOnly />
          </div>

          <div className="space-y-2">
            <Label htmlFor="price" className="uppercase text-xs font-semibold">
              Price of book
            </Label>
            <Input id="price" type="number" value={formData.price} onChange={handlePriceChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="discount" className="uppercase text-xs font-semibold">
              Discount
            </Label>
            <Input id="discount" type="number" value={formData.discount} onChange={handleDiscountChange} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="totalPayment" className="uppercase text-xs font-semibold">
              Total payment
            </Label>
            <Input id="totalPayment" type="number" value={formData.totalPayment} readOnly />
          </div>

          <div className="flex justify-center gap-4 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              OK
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

