"use client"

import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { CheckCircle2 } from "lucide-react"
import type { BorrowedBook } from "@/lib/types"

interface ReturnBookDialogProps {
  isOpen: boolean
  bookId: string | null
  borrowedBooks: BorrowedBook[]
  onClose: () => void
  onSuccess: (id: string) => void
}

export function ReturnBookDialog({ isOpen, bookId, borrowedBooks, onClose, onSuccess }: ReturnBookDialogProps) {
  const handleReturn = () => {
    if (bookId) {
      onSuccess(bookId)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] text-center py-10">
        <div className="flex flex-col items-center gap-4">
          <CheckCircle2 className="h-12 w-12 text-blue-500" />
          <h2 className="text-xl font-semibold">Returned book successfully</h2>
          <Button onClick={handleReturn} className="mt-4 bg-blue-600 hover:bg-blue-700 px-8">
            Continue
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

