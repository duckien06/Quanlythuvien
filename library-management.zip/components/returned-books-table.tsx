import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { BorrowedBook } from "@/lib/types"

interface ReturnedBooksTableProps {
  returnedBooks: BorrowedBook[]
}

export function ReturnedBooksTable({ returnedBooks }: ReturnedBooksTableProps) {
  // Filter only returned books
  const filteredBooks = returnedBooks.filter((book) => book.status === "returned")

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Phone</TableHead>
            <TableHead>Book</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Return date</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredBooks.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.customerName}</TableCell>
              <TableCell>{item.customerPhone}</TableCell>
              <TableCell>{item.bookTitle}</TableCell>
              <TableCell>{item.bookCategory}</TableCell>
              <TableCell>{item.returnedAt || item.returnDate}</TableCell>
            </TableRow>
          ))}
          {filteredBooks.length === 0 && (
            <TableRow>
              <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                No returned books found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  )
}

