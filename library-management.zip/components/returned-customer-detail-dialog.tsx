"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useLibraryStore } from "@/lib/store"

interface ReturnedCustomerDetailDialogProps {
  customerId: string | null
  onClose: () => void
}

export function ReturnedCustomerDetailDialog({ customerId, onClose }: ReturnedCustomerDetailDialogProps) {
  const { borrowedBooks } = useLibraryStore()

  if (!customerId) return null

  // Get customer's returned books
  const customerBooks = borrowedBooks.filter((book) => book.customerId === customerId && book.status === "returned")

  // Get customer name from the first book (if any)
  const customerName = customerBooks.length > 0 ? customerBooks[0].customerName : "Customer"

  return (
    <Dialog open={!!customerId} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px]">
        <DialogHeader>
          <DialogTitle>Books returned by {customerName}</DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Book</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Borrowed date</TableHead>
                <TableHead>Return date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customerBooks.map((book) => (
                <TableRow key={book.id}>
                  <TableCell>{book.bookTitle}</TableCell>
                  <TableCell>{book.bookCategory}</TableCell>
                  <TableCell>{book.borrowedDate}</TableCell>
                  <TableCell>{book.returnedAt || book.returnDate}</TableCell>
                </TableRow>
              ))}
              {customerBooks.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-gray-500">
                    No returned books found for this customer
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  )
}

