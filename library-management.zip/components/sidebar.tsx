"use client"

import type React from "react"

import Link from "next/link"
import { usePathname, useSearchParams } from "next/navigation"
import { cn } from "@/lib/utils"
import { Home, BookCopy, Library, Tag, Users, UserRound, Mail } from "lucide-react"
import { Suspense } from "react"

interface NavItem {
  label: string
  href: string
  icon: React.ReactNode
}

function SidebarContent() {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const isSearching = searchParams.has("q")

  const navItems: NavItem[] = [
    {
      label: "Home",
      href: "/",
      icon: <Home className="h-5 w-5" />,
    },
    {
      label: "Borrow / Return Books",
      href: "/borrow-return",
      icon: <BookCopy className="h-5 w-5" />,
    },
    {
      label: "Book management",
      href: "/book-management",
      icon: <Library className="h-5 w-5" />,
    },
    {
      label: "Category management",
      href: "/category-management",
      icon: <Tag className="h-5 w-5" />,
    },
    {
      label: "Author management",
      href: "/author-management",
      icon: <UserRound className="h-5 w-5" />,
    },
    {
      label: "Reader management",
      href: "/reader-management",
      icon: <Users className="h-5 w-5" />,
    },
    {
      label: "Management receives information",
      href: "/email-notification",
      icon: <Mail className="h-5 w-5" />,
    },
  ]

  return (
    <nav className="py-4">
      <ul className="space-y-1">
        {navItems.map((item) => (
          <li key={item.href}>
            <Link
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-4 py-2.5 text-sm font-medium transition-colors",
                (pathname === item.href && !isSearching) || (pathname.startsWith(item.href) && item.href !== "/")
                  ? "bg-blue-600 text-white"
                  : "text-gray-600 hover:bg-gray-100",
              )}
            >
              {item.icon}
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  )
}

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r border-gray-200 min-h-[calc(100vh-3rem)]">
      <Suspense fallback={<div className="py-4 px-4">Loading...</div>}>
        <SidebarContent />
      </Suspense>
    </aside>
  )
}

