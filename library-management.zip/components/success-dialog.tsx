"use client"

import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { CheckCircle2 } from "lucide-react"

interface SuccessDialogProps {
  isOpen: boolean
  onClose: () => void
  message?: string
}

export function SuccessDialog({ isOpen, onClose, message = "Added successfully" }: SuccessDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] text-center py-10">
        <div className="flex flex-col items-center gap-4">
          <CheckCircle2 className="h-12 w-12 text-blue-500" />
          <h2 className="text-xl font-semibold">{message}</h2>
          <Button onClick={onClose} className="mt-4 bg-blue-600 hover:bg-blue-700 px-8">
            Continue
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

