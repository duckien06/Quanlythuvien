import type { BorrowedBook, Customer } from "./types"

export const borrowedBooks: BorrowedBook[] = [
  {
    id: "b1",
    customerId: "c1",
    customerName: "Kien",
    customerPhone: "01511115166",
    bookId: "1",
    bookTitle: "Mắt biếc",
    bookCategory: "Short story",
    borrowedDate: "03.03.2025",
    returnDate: "13.03.2025",
    status: "borrowed",
  },
  {
    id: "b2",
    customerId: "c1",
    customerName: "Kien",
    customerPhone: "01511115166",
    bookId: "2",
    bookTitle: "10 điểm",
    bookCategory: "Short story",
    borrowedDate: "03.03.2025",
    returnDate: "13.03.2025",
    status: "borrowed",
  },
  {
    id: "b3",
    customerId: "c2",
    customerName: "Huong",
    customerPhone: "0514548151",
    bookId: "1",
    bookTitle: "Mắt biếc",
    bookCategory: "Short story",
    borrowedDate: "03.03.2025",
    returnDate: "13.03.2025",
    status: "borrowed",
  },
  {
    id: "b4",
    customerId: "c3",
    customerName: "Ngoc",
    customerPhone: "0548498451",
    bookId: "1",
    bookTitle: "Mắt biếc",
    bookCategory: "Short story",
    borrowedDate: "03.03.2025",
    returnDate: "13.03.2025",
    status: "borrowed",
  },
]

export const customers: Customer[] = [
  {
    id: "c1",
    name: "Kien",
    phone: "01511115166",
    borrowedQuantity: 2,
  },
  {
    id: "c2",
    name: "Huong",
    phone: "0514548151",
    borrowedQuantity: 1,
  },
  {
    id: "c3",
    name: "Ngoc",
    phone: "0548498451",
    borrowedQuantity: 1,
  },
]

