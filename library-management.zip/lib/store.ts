import { create } from "zustand"
import type { BorrowedBook, Customer } from "./types"
import { borrowedBooks as initialBorrowedBooks, customers as initialCustomers } from "./borrow-data"

interface LibraryStore {
  borrowedBooks: BorrowedBook[]
  returnedBooks: BorrowedBook[]
  customers: Customer[]

  // Actions
  addBorrowedBook: (book: Omit<BorrowedBook, "id" | "status">) => void
  updateBorrowedBook: (id: string, data: Partial<BorrowedBook>) => void
  deleteBorrowedBook: (id: string) => void
  returnBook: (id: string) => void
  markBookAsLost: (id: string, price: number, discount: number) => void
}

export const useLibraryStore = create<LibraryStore>((set) => ({
  borrowedBooks: initialBorrowedBooks,
  returnedBooks: initialBorrowedBooks.filter((book) => book.status === "returned"),
  customers: initialCustomers,

  addBorrowedBook: (book) =>
    set((state) => {
      const newBook: BorrowedBook = {
        ...book,
        id: `b${state.borrowedBooks.length + 1}`,
        status: "borrowed",
      }

      // Update customer's borrowed quantity
      const updatedCustomers = state.customers.map((customer) => {
        if (customer.id === book.customerId) {
          return {
            ...customer,
            borrowedQuantity: customer.borrowedQuantity + 1,
          }
        }
        return customer
      })

      return {
        borrowedBooks: [...state.borrowedBooks, newBook],
        customers: updatedCustomers,
      }
    }),

  updateBorrowedBook: (id, data) =>
    set((state) => ({
      borrowedBooks: state.borrowedBooks.map((book) => (book.id === id ? { ...book, ...data } : book)),
    })),

  deleteBorrowedBook: (id) =>
    set((state) => {
      const bookToDelete = state.borrowedBooks.find((book) => book.id === id)

      if (!bookToDelete) return state

      // Update customer's borrowed quantity
      const updatedCustomers = state.customers.map((customer) => {
        if (customer.id === bookToDelete.customerId && bookToDelete.status === "borrowed") {
          return {
            ...customer,
            borrowedQuantity: Math.max(0, customer.borrowedQuantity - 1),
          }
        }
        return customer
      })

      return {
        borrowedBooks: state.borrowedBooks.filter((book) => book.id !== id),
        customers: updatedCustomers,
      }
    }),

  returnBook: (id) =>
    set((state) => {
      const currentDate = new Date()
        .toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        })
        .split("/")
        .join(".")

      const updatedBorrowedBooks = state.borrowedBooks.map((book) =>
        book.id === id
          ? {
              ...book,
              status: "returned",
              returnedAt: currentDate,
            }
          : book,
      )

      // Update customer's borrowed quantity
      const bookToReturn = state.borrowedBooks.find((book) => book.id === id)
      const updatedCustomers = state.customers.map((customer) => {
        if (bookToReturn && customer.id === bookToReturn.customerId) {
          return {
            ...customer,
            borrowedQuantity: Math.max(0, customer.borrowedQuantity - 1),
          }
        }
        return customer
      })

      return {
        borrowedBooks: updatedBorrowedBooks,
        returnedBooks: updatedBorrowedBooks.filter((book) => book.status === "returned"),
        customers: updatedCustomers,
      }
    }),

  markBookAsLost: (id, price, discount) =>
    set((state) => {
      const currentDate = new Date()
        .toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
        })
        .split("/")
        .join(".")

      const totalPayment = price - discount

      const updatedBorrowedBooks = state.borrowedBooks.map((book) =>
        book.id === id
          ? {
              ...book,
              status: "lost",
              lostAt: currentDate,
              lostBookPrice: price,
              lostBookDiscount: discount,
              lostBookTotalPayment: totalPayment,
            }
          : book,
      )

      // Update customer's borrowed quantity
      const bookToMark = state.borrowedBooks.find((book) => book.id === id)
      const updatedCustomers = state.customers.map((customer) => {
        if (bookToMark && customer.id === bookToMark.customerId) {
          return {
            ...customer,
            borrowedQuantity: Math.max(0, customer.borrowedQuantity - 1),
          }
        }
        return customer
      })

      return {
        borrowedBooks: updatedBorrowedBooks,
        customers: updatedCustomers,
      }
    }),
}))

