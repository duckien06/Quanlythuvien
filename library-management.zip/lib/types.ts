export interface Book {
  id: string
  code: string
  title: string
  author: string
  category: string
  publicationDate: string
  status: "available" | "borrowed"
}

export interface BorrowedBook {
  id: string
  customerId: string
  customerName: string
  customerPhone: string
  bookId: string
  bookTitle: string
  bookCategory: string
  borrowedDate: string
  returnDate: string
  status: "borrowed" | "returned" | "lost"
  returnedAt?: string
  lostAt?: string
  lostBookPrice?: number
  lostBookDiscount?: number
  lostBookTotalPayment?: number
}

export interface Customer {
  id: string
  name: string
  phone: string
  borrowedQuantity: number
}

export interface ReturnedBook extends BorrowedBook {
  returnedAt: string
}

export interface LostBook extends BorrowedBook {
  lostAt: string
  lostBookPrice: number
  lostBookDiscount: number
  lostBookTotalPayment: number
}

